-- 地图玩法属性：泉眼出生选择、显式机关连接。坐标保持1基，不自动连最近的门。
local ME = require "core.map_editor"
local TM = require "core.tilemap"
local EG = {}

local LABELS = {}
for _, item in ipairs(ME.PALETTE) do LABELS[item.char] = item.label end
LABELS.t = "出生点"

---@param col integer
---@param row integer
---@return string
function EG.key(col, row) return col .. ":" .. row end

function EG.id(col, row)
    return string.format("%s_%d_%d", ME.metadata.progressId or ME.currentLevel or "world", col - 1, row - 1)
end

function EG.select(col, row)
    if not ME.grid[row] or not ME.grid[row][col] then return false end
    ME.selectedCell = { col = col, row = row }
    return true
end

function EG.selected()
    local cell = ME.selectedCell
    if not cell or not ME.grid[cell.row] then return nil end
    local char = ME.grid[cell.row][cell.col]
    if not char or char == " " then return nil end
    return { col = cell.col, row = cell.row, char = char, key = EG.key(cell.col, cell.row),
        id = EG.id(cell.col, cell.row), label = LABELS[char] or char }
end

function EG.list(chars)
    local list = {}
    for row, line in ipairs(ME.grid) do
        for col, char in ipairs(line) do
            if char ~= " " and chars:find(char, 1, true) then
                list[#list + 1] = { col = col, row = row, char = char, key = EG.key(col, row),
                    id = EG.id(col, row), label = (LABELS[char] or char) .. "（" .. col .. "," .. row .. "）" }
            end
        end
    end
    return list
end

---@param key string
---@return boolean, string
function EG.setInitial(key)
    local col, row = TM.cellCoords(key, ME.cols, ME.rows)
    if not col or not row then return false, "出生点坐标无效" end
    local char = ME.grid[row][col]
    if char ~= "S" and char ~= "t" then return false, "请选择泉眼或出生点标记" end
    local state = ME.getLayerState("gameplay")
    if state.locked or not state.visible then return false, "请先显示并解锁玩法标记层" end
    ME.metadata.initialSpawnCell = { col = col, row = row }
    local x, y = ME.cellToWorld(col, row)
    ME.metadata.spawn = { x = x, y = y + (char == "S" and 0.8 or 0.4) }
    ME.markDirty()
    print("[地图玩法] 初始出生选择 " .. key)
    return true, "已设初始出生点（" .. col .. "," .. row .. "）；试玩从此处开始"
end

function EG.initialKey()
    local cell = ME.metadata.initialSpawnCell
    if type(cell) ~= "table" then return "" end
    if not TM.validDimensions(cell.col, cell.row) or not ME.grid[cell.row] then return "" end
    local char = ME.grid[cell.row][cell.col]
    return (char == "S" or char == "t") and EG.key(cell.col, cell.row) or ""
end

function EG.properties(key)
    local all = ME.metadata.elementProperties
    return type(all) == "table" and type(all[key]) == "table" and all[key] or {}
end

function EG.setProperty(key, name, value)
    local col, row = TM.cellCoords(key, ME.cols, ME.rows)
    if not col or not row then return false end
    local state = ME.getLayerState("gameplay")
    if state.locked or not state.visible then return false end
    if name ~= "active" and name ~= "needsPower" and name ~= "open" then return false end
    ME.metadata.elementProperties = ME.metadata.elementProperties or {}
    ME.metadata.elementProperties[key] = ME.metadata.elementProperties[key] or {}
    ME.metadata.elementProperties[key][name] = value == true
    ME.markDirty()
    return true
end

function EG.connect(sourceKey, targetKey)
    local sc, sr = TM.cellCoords(sourceKey, ME.cols, ME.rows)
    local tc, tr = TM.cellCoords(targetKey, ME.cols, ME.rows)
    if not sc or not sr or not tc or not tr then return false, "请选择有效连接端点" end
    local source, target = ME.grid[sr][sc], ME.grid[tr][tc]
    if (source ~= "P" and source ~= "O") or (target ~= "D" and target ~= "A") then return false, "仅支持压板/电力接口连接门/报警器" end
    local state = ME.getLayerState("gameplay")
    if state.locked or not state.visible then return false, "请先显示并解锁玩法标记层" end
    local from, to = EG.id(sc, sr), EG.id(tc, tr)
    ME.metadata.wires = ME.metadata.wires or {}
    for _, wire in ipairs(ME.metadata.wires) do
        if wire.from == from and wire.to == to then return false, "该连接已经存在" end
    end
    ME.metadata.wires[#ME.metadata.wires + 1] = { from = from, to = to }
    EG.setProperty(targetKey, "needsPower", true)
    print("[地图玩法] 连接 " .. from .. " -> " .. to)
    return true, "连接已添加；压板需固态踩下，电力接口需装备电鳗并靠近"
end

function EG.disconnect(targetKey)
    local col, row = TM.cellCoords(targetKey, ME.cols, ME.rows)
    if not col or not row then return false end
    local state = ME.getLayerState("gameplay")
    if state.locked or not state.visible then return false end
    local id, wires, changed = EG.id(col, row), {}, false
    for _, wire in ipairs(ME.metadata.wires or {}) do
        if wire.to == id then changed = true else wires[#wires + 1] = wire end
    end
    if changed then ME.metadata.wires = wires; ME.markDirty() end
    return changed
end

return EG
