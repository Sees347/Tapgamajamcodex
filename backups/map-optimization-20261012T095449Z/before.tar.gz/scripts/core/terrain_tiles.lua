-- 连续墙体的四邻接切片；不修改地图编号、格坐标、碰撞或原图。
-- 仅修正已测量的工业墙体第 1 槽：透明槽边不进格，完整外轮廓只保留在外露边。
local T = {}

---@class TerrainSourceRect
---@field x integer
---@field y integer
---@field width integer
---@field height integer

---@param definition MapTilesetDefinition
---@param cell VisualMapCell?
---@return boolean
local function connects(definition, cell)
    return type(cell) == "table" and cell.tilesetId == definition.id and cell.tileId == 1
        and cell.collider == "ground"
end

---@param definition MapTilesetDefinition
---@param layer VisualMapLayer
---@param col integer
---@param row integer
---@return TerrainSourceRect?
function T.sourceRect(definition, layer, col, row)
    -- 自定义切片配置、其他墙片、薄平台和装饰仍按原槽绘制。
    if definition.id ~= "industrial_walls"
        or definition.path ~= "image/地图/tiles/industrial_walls.png"
        or definition.cellWidth ~= 256 or definition.cellHeight ~= 256
        or definition.margin ~= 0 or definition.spacing ~= 0
        or definition.imageWidth ~= 1536 or definition.imageHeight ~= 1024
        or not connects(definition, layer.cells[string.format("%d:%d", col, row)]) then return nil end

    -- bbox 为 [12,243)×[4,252)；内填充 [24,232)×[16,240) 全 alpha=255。
    -- 连通边使用内部纹理，外露边/外转角保留原轮廓；不扩大目标格或叠画邻格。
    local left = connects(definition, layer.cells[string.format("%d:%d", col - 1, row)])
    local right = connects(definition, layer.cells[string.format("%d:%d", col + 1, row)])
    local above = connects(definition, layer.cells[string.format("%d:%d", col, row - 1)])
    local below = connects(definition, layer.cells[string.format("%d:%d", col, row + 1)])
    local x0, x1 = left and 24 or 12, right and 232 or 243
    local y0, y1 = above and 16 or 4, below and 240 or 252
    return { x = x0, y = y0, width = math.floor(x1 - x0), height = math.floor(y1 - y0) }
end

return T
